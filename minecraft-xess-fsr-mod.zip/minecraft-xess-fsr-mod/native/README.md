Sample native JNI shim

This folder contains a small C++ JNI shim that implements the JNI symbols expected by `NativeUpscaler`.

It does NOT call into Intel XeSS or AMD FSR SDKs; it's a dummy implementation that copies source bytes to destination.

Windows build (Visual Studio / MSBuild)

- Open a Developer Command Prompt for Visual Studio and run cmake to generate a Visual Studio solution:

```powershell
cd native
mkdir build; cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

- The resulting DLL will be in `build/Release` named `xess_native.dll` (or `fsr_native.dll` depending on the target name defined in CMake).

CMake

- The project defines two targets: `xess_native` and `fsr_native`. You can build either.

Notes

- Adjust include paths for your JDK if CMake can't find JNI headers automatically.
- The JNI method signatures correspond to the private static native methods in `NativeUpscaler`.
