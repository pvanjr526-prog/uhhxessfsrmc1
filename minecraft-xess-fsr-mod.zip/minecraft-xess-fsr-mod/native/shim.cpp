#include <jni.h>
#include <cstring>
#include <iostream>

// Helper to find the JNI environment and class names. These signatures match
// the private static native methods in com.example.xessfsr.NativeUpscaler

extern "C" {

JNIEXPORT void JNICALL Java_com_example_xessfsr_NativeUpscaler_nativeInit(JNIEnv* env, jclass cls) {
    // No-op init for dummy shim
    std::cout << "nativeInit called" << std::endl;
}

JNIEXPORT void JNICALL Java_com_example_xessfsr_NativeUpscaler_nativeUpscale(JNIEnv* env, jclass cls,
    jint srcW, jint srcH, jbyteArray src, jint dstW, jint dstH, jbyteArray dst) {
    // Simple copy-based upscale: if sizes match, copy; otherwise, nearest-neighbor resize
    if (src == nullptr || dst == nullptr) return;

    jsize srcLen = env->GetArrayLength(src);
    jsize dstLen = env->GetArrayLength(dst);

    jbyte* srcBytes = env->GetByteArrayElements(src, NULL);
    jbyte* dstBytes = env->GetByteArrayElements(dst, NULL);
    if (!srcBytes || !dstBytes) {
        if (srcBytes) env->ReleaseByteArrayElements(src, srcBytes, JNI_ABORT);
        if (dstBytes) env->ReleaseByteArrayElements(dst, dstBytes, 0);
        return;
    }

    const int bpp = 4;
    if (srcW == dstW && srcH == dstH) {
        // direct copy
        memcpy(dstBytes, srcBytes, (size_t) (bpp * srcW * srcH < srcLen ? bpp * srcW * srcH : srcLen));
    } else {
        for (int y = 0; y < dstH; y++) {
            int srcY = (int)((long long)y * srcH / dstH);
            for (int x = 0; x < dstW; x++) {
                int srcX = (int)((long long)x * srcW / dstW);
                int sIdx = (srcY * srcW + srcX) * bpp;
                int dIdx = (y * dstW + x) * bpp;
                if (sIdx + 3 < srcLen && dIdx + 3 < dstLen) {
                    dstBytes[dIdx] = srcBytes[sIdx];
                    dstBytes[dIdx+1] = srcBytes[sIdx+1];
                    dstBytes[dIdx+2] = srcBytes[sIdx+2];
                    dstBytes[dIdx+3] = srcBytes[sIdx+3];
                }
            }
        }
    }

    env->ReleaseByteArrayElements(src, srcBytes, JNI_ABORT);
    env->ReleaseByteArrayElements(dst, dstBytes, 0);
}

JNIEXPORT void JNICALL Java_com_example_xessfsr_NativeUpscaler_nativeShutdown(JNIEnv* env, jclass cls) {
    std::cout << "nativeShutdown called" << std::endl;
}

} // extern "C"
