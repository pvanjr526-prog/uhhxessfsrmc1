package com.example.xessfsr;

import org.slf4j.Logger;

public class JavaFallbackUpscaler implements Upscaler {
    private final Logger logger = XessFsrMod.LOGGER;

    @Override
    public boolean init() {
        logger.info("JavaFallbackUpscaler initialized");
        return true;
    }

    @Override
    public void upscale(int srcWidth, int srcHeight, byte[] srcRGBA, int dstWidth, int dstHeight, byte[] dstRGBA) {
        // Simple nearest-neighbor upscale from src to dst. Expects 4 bytes per pixel (RGBA).
        if (srcRGBA == null || dstRGBA == null) return;
        final int srcBpp = 4;
        for (int y = 0; y < dstHeight; y++) {
            int srcY = (int)((long)y * srcHeight / dstHeight);
            for (int x = 0; x < dstWidth; x++) {
                int srcX = (int)((long)x * srcWidth / dstWidth);
                int srcIdx = (srcY * srcWidth + srcX) * srcBpp;
                int dstIdx = (y * dstWidth + x) * srcBpp;
                if (srcIdx + 3 >= srcRGBA.length || dstIdx + 3 >= dstRGBA.length) continue;
                dstRGBA[dstIdx] = srcRGBA[srcIdx];
                dstRGBA[dstIdx + 1] = srcRGBA[srcIdx + 1];
                dstRGBA[dstIdx + 2] = srcRGBA[srcIdx + 2];
                dstRGBA[dstIdx + 3] = srcRGBA[srcIdx + 3];
            }
        }
    }

    @Override
    public void shutdown() {
        logger.info("JavaFallbackUpscaler shutdown");
    }

    @Override
    public String getName() {
        return "JavaFallback";
    }
}
