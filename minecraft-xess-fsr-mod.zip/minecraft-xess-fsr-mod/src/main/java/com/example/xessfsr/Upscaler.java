package com.example.xessfsr;

public interface Upscaler {
    /** Initialize the upscaler with native libs; return true on success. */
    boolean init();

    /** Upscale a source RGBA buffer into a destination buffer. */
    void upscale(int srcWidth, int srcHeight, byte[] srcRGBA, int dstWidth, int dstHeight, byte[] dstRGBA);

    /** Shutdown and free native resources. */
    void shutdown();

    /** Return the name/vendor of this upscaler. */
    String getName();
}
