package com.example.xessfsr;

import org.slf4j.Logger;

public class UpscalerManager {
    private static Upscaler active;

    public static void init() {
        // Try to load Intel XeSS native first, then AMD FSR as fallback.
        try {
            Logger logger = XessFsrMod.LOGGER;
            logger.info("Attempting to load Intel XeSS native wrapper...");
            if (NativeLoader.loadLibrary("xess_native")) {
                Upscaler xess = new NativeUpscaler("Intel XeSS");
                if (xess.init()) {
                    active = xess;
                    logger.info("Loaded Intel XeSS upscaler");
                    return;
                }
            }
        } catch (Throwable t) {
            XessFsrMod.LOGGER.warn("XeSS load failed: ", t);
        }

        try {
            XessFsrMod.LOGGER.info("Attempting to load AMD FSR native wrapper...");
            if (NativeLoader.loadLibrary("fsr_native")) {
                Upscaler fsr = new NativeUpscaler("AMD FSR");
                if (fsr.init()) {
                    active = fsr;
                    XessFsrMod.LOGGER.info("Loaded AMD FSR upscaler");
                    return;
                }
            }
        } catch (Throwable t) {
            XessFsrMod.LOGGER.warn("FSR load failed: ", t);
        }

        XessFsrMod.LOGGER.info("No native upscaler loaded");
        // As a last-resort, enable a pure-Java fallback upscaler so the mod is usable
        // out-of-the-box without vendor native libraries. This fallback performs a
        // simple nearest-neighbor upscale and is intended for testing only.
        try {
            XessFsrMod.LOGGER.info("Using Java fallback upscaler");
            active = new JavaFallbackUpscaler();
            if (active.init()) {
                XessFsrMod.LOGGER.info("Java fallback upscaler active");
            }
        } catch (Throwable t) {
            XessFsrMod.LOGGER.warn("Failed to start Java fallback upscaler: ", t);
        }
    }

    public static Upscaler getActive() {
        return active;
    }

    public static void shutdown() {
        if (active != null) {
            active.shutdown();
            active = null;
        }
    }
}
