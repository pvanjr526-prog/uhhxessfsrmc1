package com.example.xessfsr;

public class NativeUpscaler implements Upscaler {
    private final String name;

    public NativeUpscaler(String name) {
        this.name = name;
    }

    @Override
    public boolean init() {
        // The real implementation would call nativeInit();
        try {
            nativeInit();
            return true;
        } catch (UnsatisfiedLinkError e) {
            return false;
        }
    }

    @Override
    public void upscale(int srcWidth, int srcHeight, byte[] srcRGBA, int dstWidth, int dstHeight, byte[] dstRGBA) {
        nativeUpscale(srcWidth, srcHeight, srcRGBA, dstWidth, dstHeight, dstRGBA);
    }

    @Override
    public void shutdown() {
        nativeShutdown();
    }

    @Override
    public String getName() {
        return name;
    }

    // Native method stubs - these must be implemented in the native library.
    private static native void nativeInit();
    private static native void nativeUpscale(int srcW, int srcH, byte[] src, int dstW, int dstH, byte[] dst);
    private static native void nativeShutdown();
}
