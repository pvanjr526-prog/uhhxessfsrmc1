package com.example.xessfsr;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XessFsrMod implements ModInitializer {
    public static final String MOD_ID = "xessfsr";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("XessFsrMod initializing");
        // Initialize native loader (will attempt to find vendor libs)
        UpscalerManager.init();
    }
}
