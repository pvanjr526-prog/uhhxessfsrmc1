package com.example.xessfsr;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class NativeLoader {
    /**
     * Try to load a native library by name from several locations:
     * - System.loadLibrary(name) (platform default)
     * - A 'natives' folder inside the mod JAR extracted to a temp location
     * - A 'natives' folder next to the mod jar (not implemented here)
     *
     * This method will not extract or provide vendor binaries. The user must supply them.
     */
    public static boolean loadLibrary(String name) {
        try {
            System.loadLibrary(name);
            return true;
        } catch (UnsatisfiedLinkError e) {
            // try to load bundled native from resources
        }

        String resourcePath = "/natives/" + libFileName(name);
        try (InputStream in = NativeLoader.class.getResourceAsStream(resourcePath)) {
            if (in == null) return false;
            File temp = File.createTempFile(name + "-", "-native");
            temp.deleteOnExit();
            Files.copy(in, temp.toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.load(temp.getAbsolutePath());
            return true;
        } catch (IOException | UnsatisfiedLinkError ex) {
            return false;
        }
    }

    private static String libFileName(String name) {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) return name + ".dll";
        if (os.contains("mac")) return "lib" + name + ".dylib";
        return "lib" + name + ".so";
    }
}
