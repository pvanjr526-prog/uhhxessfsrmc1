Minecraft XeSS/FSR Mod (Fabric)

This repository is a minimal Fabric mod skeleton that shows how to add vendor upscalers — Intel XeSS and AMD FSR — into Minecraft via native libraries and a small Java/native bridge. It does NOT include vendor SDKs or their binaries: those are proprietary and must be obtained from Intel/AMD and added by you.

What's included

- Gradle build files (Fabric Loom)
- Mod metadata (fabric.mod.json)
- Java skeleton wiring: mod initializer, Upscaler API, Native loader stub
- README with build and install instructions

Requirements

- Java 17+ (JDK)
- Gradle (or use the Gradle wrapper)
- Fabric development environment (Fabric Loom plugin will be used by Gradle)

How this works

- The mod defines an Upscaler interface in Java (init, upscale, shutdown). Native libraries (JNI) implement the platform-specific calls to Intel XeSS or AMD FSR.
- You must compile or obtain prebuilt native libraries (DLL/.so/.dylib) and put them into the mod JAR's natives folder or load them externally on startup.


Important notes

- Intel XeSS and AMD FSR are provided under their own licenses; this project does NOT include those SDKs or any vendor binaries. You must obtain them directly from the vendor sites and comply with their licensing.
- Frame Generation features (i.e., driver-level frame generation) are out of scope for a simple Java mod because they require driver support and deeper integration with the GPU/driver stack. This repository provides a JNI/native-hook skeleton and Java wiring only.

Obtaining vendor SDKs and binaries

- Intel XeSS: available from Intel's developer resources. Look for the XeSS SDK which contains headers and prebuilt binaries for supported platforms.
- AMD FSR: available from AMD's GPUOpen site. The FSR SDK and sample code include binaries and headers.

How to add native libraries

1. After obtaining or building native wrappers (see next section), place their files in one of the following locations before launching Minecraft:
	 - Inside the mod JAR under /natives/<platform>/ (recommended for packaging). Example Windows filenames: `xess_native.dll`, `fsr_native.dll`.
	 - In the JVM library path (System.loadLibrary can find them if they are in PATH or java.library.path).
	 - Next to the mod JAR in a folder named `natives` and modify `NativeLoader` to probe that folder.

2. When packaging the mod, include the correct native for each platform and CPU architecture. Don't redistribute vendor SDK code unless the license explicitly permits it.

JNI/native wrapper notes

- This project exposes three native stubs in `NativeUpscaler`:
	- `nativeInit()` - initialize the vendor upscaler and allocate resources.
	- `nativeUpscale(...)` - accept source RGBA bytes and write upscaled result.
	- `nativeShutdown()` - free vendor resources.

- The native library must implement those JNI symbols. A small C/C++ shim should translate between Java byte arrays and the vendor SDK image buffers and call the appropriate XeSS/FSR APIs.

Building (local)

This project uses Gradle + Fabric Loom. On Windows PowerShell, you can run:

```powershell
.
# If you have the Gradle wrapper (not included), run:
./gradlew build

# Or use your system gradle:
gradle build
```

If you run into Java version issues, ensure your `JAVA_HOME` points to a JDK 17+ and your PATH uses that Java.

Running in the development environment

- Use the Fabric Loom tasks to run the client with the mod in the dev environment (requires setup in `build.gradle` and a configured loom environment). This skeleton uses basic loom settings; you may need to adjust versions.

Next steps (developer-friendly)

1. Implement a small native shim in C/C++ that links to XeSS/FSR SDKs and exposes the JNI functions. Provide a CMake or Visual Studio project to build the DLLs.
2. Hook into Minecraft's framebuffer/render pipeline to call the active upscaler on render textures (this requires knowledge of the renderer used by your target Minecraft version).
3. Add an in-game toggle and GUI for choosing between XeSS/FSR and for enabling frame generation features when supported.

If you want, I can:

- Create a sample C++ JNI shim that exposes the three functions and demonstrates copying image buffers (without calling vendor SDKs), so you can test the mod end-to-end with a dummy upscaler.
- Try to run a local Gradle build in this environment (I will need a JDK and Gradle wrapper present). 

What I added for quick testing

- A pure-Java fallback upscaler (`JavaFallbackUpscaler`) is included and will be used automatically if no native libraries are found. It performs a simple nearest-neighbor upscale so you can test the mod without native vendor libs.
- A sample native JNI shim is included under `native/` which builds two targets: `xess_native` and `fsr_native`. These are dummy DLLs that implement the JNI symbols but do not call vendor SDKs.

How to build the sample native shim on Windows (PowerShell)

```powershell
cd native
mkdir build; cd build
# Generate a Visual Studio solution (adjust generator to your installed VS)
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release

# After building, copy the produced DLL(s) into the mod's resources for testing, for example:
# copy .\Release\xess_native.dll ..\..\src\main\resources\natives\xess_native.dll
```

Testing Java fallback in dev client

- Because `JavaFallbackUpscaler` is used automatically when no native libraries are present, you can run the Fabric dev client (via Loom) and verify that the mod initializes and logs the fallback activation. The fallback does not improve image quality; it's purely for functional testing.

Packaging vendor natives

- When you have vendor native libraries (Intel XeSS or AMD FSR), build or obtain native wrappers that implement the JNI API and include them in the mod JAR under `/natives/` or place them on the JVM library path before launching Minecraft. Ensure filenames match the ones the loader expects (example: `xess_native.dll`, `fsr_native.dll`).





